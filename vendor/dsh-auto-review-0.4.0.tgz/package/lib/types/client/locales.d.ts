/**
 * Copy dictionaries for the auto-review session-header panel (en/zh — the
 * harness locale registry accepts these two UI language codes today).
 * @module dsh-auto-review/client/locales
 */
/** Simplified Chinese dictionary and key source of truth. */
export declare const zh: {
    label: string;
    title: string;
    state: string;
    stateOn: string;
    stateOff: string;
    enable: string;
    disable: string;
    verdicts: string;
    failures: string;
    allTime: string;
    allows: string;
    denies: string;
    fallbacks: string;
    neverRejects: string;
    avg: string;
    circuit: string;
    circuitDetail: string;
    empty: string;
    recent: string;
    denyList: string;
    approve: string;
    approveResult: string;
    approveFailed: string;
    switchedResult: string;
    switchFailed: string;
    unavailable: string;
    decisionAllow: string;
    decisionDeny: string;
    fallbackLabel: string;
    escalationLabel: string;
    riskLow: string;
    riskMedium: string;
    riskHigh: string;
    ms: string;
};
/** Auto-review panel locale key union. */
export type ReviewPanelLocaleKey = keyof typeof zh;
/** English dictionary checked against the Chinese key set. */
export declare const en: Record<ReviewPanelLocaleKey, string>;
/** Dictionary namespace owned by this plugin. */
export declare const NS = "autoReviewPanel";
//# sourceMappingURL=locales.d.ts.map