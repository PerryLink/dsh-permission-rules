/**
 * Report writers for dsh-eval: a machine-readable JSON report (the complete
 * owned run data, including every case trace) and a human-readable Markdown
 * report with per-case assertion tables, review verdicts, and replay links
 * to the per-case session artifacts. Pure over owned {@link SuiteReport}
 * data — no live DSH references.
 * @module dsh-auto-review/eval/report
 */
import type { SuiteReport } from './runner.ts';
/** The CI gate: exit 0 exactly when every case passed. */
export declare function exitCodeFor(report: SuiteReport): number;
/** Render the complete Markdown report. */
export declare function renderMarkdownReport(report: SuiteReport): string;
/** A report write outcome. */
export interface ReportPaths {
    /** Absolute path of the JSON report. */
    readonly json: string;
    /** Absolute path of the Markdown report, when one was written. */
    readonly markdown?: string;
}
/**
 * Write the JSON and Markdown reports into the report directory.
 * @param report - the owned suite report.
 * @param dir - the report directory (created when missing).
 * @param names - optional file names (`json` defaults `report.json`,
 *   `markdown` defaults `report.md`; `markdown: null` skips the Markdown file).
 * @returns the written absolute paths.
 */
export declare function writeReports(report: SuiteReport, dir: string, names?: {
    json?: string;
    markdown?: string | null;
}): Promise<ReportPaths>;
/**
 * Render the terminal summary block printed by the CLI after a run.
 * @param report - the owned suite report.
 * @returns the summary text.
 */
export declare function renderTerminalSummary(report: SuiteReport): string;
//# sourceMappingURL=report.d.ts.map