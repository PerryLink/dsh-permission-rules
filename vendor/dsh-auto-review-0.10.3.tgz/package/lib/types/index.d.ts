/**
 * `dsh-auto-review` — second-model AI auto-review for DeepSeek Harness
 * approval requests. Registers an answerer on the `approval/request`
 * waterfall that, when a session has auto-review enabled and the configured
 * tool/risk policy says `ai`, runs a read-only one-shot reviewer subagent
 * (`toolFilter` allow-list, structured verdict schema) and settles the
 * request from its verdict; every other request delegates via `next()` to
 * the human answerer chain. Failures fall back per `fallbackPolicy` (default
 * fail-closed `rejected`).
 *
 * Function plugin — no default export (the Loader unwraps
 * `exports.default ?? exports`, and a stray default would discard
 * `name`/`inject`/`Config`/`apply`).
 * @module dsh-auto-review
 */
import { apply } from './runtime.js';
import type { AutoReviewRuntime } from './runtime.js';
export declare const name = "auto-review";
export declare const inject: string[];
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The mounted auto-review runtime (resolved config + answerer), provided by `apply`. */
        autoReviewRuntime: AutoReviewRuntime;
    }
}
export { apply };
export { AutoReviewRuntime } from './runtime.js';
export * from './cache.js';
export * from './call-id.js';
export * from './config.js';
export * from './events.js';
export * from './isolation.js';
export * from './review.js';
export * from './projection.js';
export * from './projection-types.js';
//# sourceMappingURL=index.d.ts.map