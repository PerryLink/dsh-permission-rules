/**
 * The dsh-eval case DSL: YAML suites of agent-evaluation cases. Each case
 * runs one isolated headless agent session; the `expect` block asserts on
 * the collected tool-call trace, tool results, final output, and token
 * budget; the optional `review` block adds a second-model review as a
 * supplementary assertion layer (reusing the same subagent seam as the
 * approval reviewer).
 *
 * Every type here is plain owned JSON — nothing crosses into session logs or
 * prompts without passing through the runners, and none of it carries live
 * Cordis/DSH references.
 * @module dsh-auto-review/eval/dsl
 */
import { z } from 'zod';
/** One entry of the ordered tool-call sequence expectation. */
declare const TOOL_CALL_EXPECTATION: z.ZodObject<{
    tool: z.ZodString;
    arguments: z.ZodOptional<z.ZodObject<{
        contains: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        equals: z.ZodOptional<z.ZodUnknown>;
        matches: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One tool-result expectation: assert on the result of the n-th call of a tool. */
declare const RESULT_EXPECTATION: z.ZodObject<{
    tool: z.ZodString;
    index: z.ZodDefault<z.ZodNumber>;
    isError: z.ZodOptional<z.ZodBoolean>;
    contains: z.ZodOptional<z.ZodString>;
    regex: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/** Final-output (last non-empty assistant text) assertions. */
declare const OUTPUT_EXPECTATION: z.ZodObject<{
    contains: z.ZodOptional<z.ZodString>;
    notContains: z.ZodOptional<z.ZodString>;
    regex: z.ZodOptional<z.ZodString>;
    notRegex: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
/** Prompt-regression expectation: the rendered system prompt must match a committed baseline. */
declare const PROMPT_EXPECTATION: z.ZodObject<{
    baseline: z.ZodOptional<z.ZodString>;
    baselineFrom: z.ZodOptional<z.ZodString>;
    allowedChanges: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strip>;
/** Stress-metric expectation: gate P99 latency, TTFT, and token generation speed. */
declare const STRESS_EXPECTATION: z.ZodObject<{
    maxP99Ms: z.ZodOptional<z.ZodNumber>;
    maxTtftMs: z.ZodOptional<z.ZodNumber>;
    minTokensPerSecond: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/** Fairness (bias-radar) expectation: a configurable lexicon of category regexes over the final output. */
declare const BIAS_EXPECTATION: z.ZodObject<{
    categories: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
    forbid: z.ZodDefault<z.ZodArray<z.ZodString>>;
    maxHits: z.ZodOptional<z.ZodNumber>;
    maxCategoryHits: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/** One evaluation case. */
declare const CASE: z.ZodObject<{
    id: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    input: z.ZodString;
    model: z.ZodOptional<z.ZodString>;
    tier: z.ZodOptional<z.ZodString>;
    timeoutMs: z.ZodOptional<z.ZodNumber>;
    maxTokens: z.ZodOptional<z.ZodNumber>;
    seedFrom: z.ZodOptional<z.ZodString>;
    files: z.ZodDefault<z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        content: z.ZodDefault<z.ZodString>;
    }, z.core.$strip>>>;
    expect: z.ZodDefault<z.ZodObject<{
        toolCalls: z.ZodDefault<z.ZodArray<z.ZodObject<{
            tool: z.ZodString;
            arguments: z.ZodOptional<z.ZodObject<{
                contains: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                equals: z.ZodOptional<z.ZodUnknown>;
                matches: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>>;
        toolCallsExact: z.ZodOptional<z.ZodArray<z.ZodString>>;
        noToolCalls: z.ZodOptional<z.ZodBoolean>;
        results: z.ZodDefault<z.ZodArray<z.ZodObject<{
            tool: z.ZodString;
            index: z.ZodDefault<z.ZodNumber>;
            isError: z.ZodOptional<z.ZodBoolean>;
            contains: z.ZodOptional<z.ZodString>;
            regex: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        output: z.ZodOptional<z.ZodObject<{
            contains: z.ZodOptional<z.ZodString>;
            notContains: z.ZodOptional<z.ZodString>;
            regex: z.ZodOptional<z.ZodString>;
            notRegex: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        turnEnds: z.ZodDefault<z.ZodEnum<{
            any: "any";
            completed: "completed";
        }>>;
        maxTokens: z.ZodOptional<z.ZodNumber>;
        prompt: z.ZodOptional<z.ZodObject<{
            baseline: z.ZodOptional<z.ZodString>;
            baselineFrom: z.ZodOptional<z.ZodString>;
            allowedChanges: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strip>>;
        stress: z.ZodOptional<z.ZodObject<{
            maxP99Ms: z.ZodOptional<z.ZodNumber>;
            maxTtftMs: z.ZodOptional<z.ZodNumber>;
            minTokensPerSecond: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
        bias: z.ZodOptional<z.ZodObject<{
            categories: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
            forbid: z.ZodDefault<z.ZodArray<z.ZodString>>;
            maxHits: z.ZodOptional<z.ZodNumber>;
            maxCategoryHits: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    review: z.ZodOptional<z.ZodObject<{
        statement: z.ZodString;
        criteria: z.ZodDefault<z.ZodArray<z.ZodString>>;
        model: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One evaluation suite. */
declare const SUITE: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    provider: z.ZodOptional<z.ZodString>;
    models: z.ZodDefault<z.ZodObject<{
        default: z.ZodOptional<z.ZodString>;
        tiers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>>;
    timeoutMs: z.ZodOptional<z.ZodNumber>;
    concurrency: z.ZodOptional<z.ZodNumber>;
    cases: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        input: z.ZodString;
        model: z.ZodOptional<z.ZodString>;
        tier: z.ZodOptional<z.ZodString>;
        timeoutMs: z.ZodOptional<z.ZodNumber>;
        maxTokens: z.ZodOptional<z.ZodNumber>;
        seedFrom: z.ZodOptional<z.ZodString>;
        files: z.ZodDefault<z.ZodArray<z.ZodObject<{
            path: z.ZodString;
            content: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>>>;
        expect: z.ZodDefault<z.ZodObject<{
            toolCalls: z.ZodDefault<z.ZodArray<z.ZodObject<{
                tool: z.ZodString;
                arguments: z.ZodOptional<z.ZodObject<{
                    contains: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                    equals: z.ZodOptional<z.ZodUnknown>;
                    matches: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                }, z.core.$strip>>;
            }, z.core.$strip>>>;
            toolCallsExact: z.ZodOptional<z.ZodArray<z.ZodString>>;
            noToolCalls: z.ZodOptional<z.ZodBoolean>;
            results: z.ZodDefault<z.ZodArray<z.ZodObject<{
                tool: z.ZodString;
                index: z.ZodDefault<z.ZodNumber>;
                isError: z.ZodOptional<z.ZodBoolean>;
                contains: z.ZodOptional<z.ZodString>;
                regex: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>>;
            output: z.ZodOptional<z.ZodObject<{
                contains: z.ZodOptional<z.ZodString>;
                notContains: z.ZodOptional<z.ZodString>;
                regex: z.ZodOptional<z.ZodString>;
                notRegex: z.ZodOptional<z.ZodString>;
            }, z.core.$strip>>;
            turnEnds: z.ZodDefault<z.ZodEnum<{
                any: "any";
                completed: "completed";
            }>>;
            maxTokens: z.ZodOptional<z.ZodNumber>;
            prompt: z.ZodOptional<z.ZodObject<{
                baseline: z.ZodOptional<z.ZodString>;
                baselineFrom: z.ZodOptional<z.ZodString>;
                allowedChanges: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strip>>;
            stress: z.ZodOptional<z.ZodObject<{
                maxP99Ms: z.ZodOptional<z.ZodNumber>;
                maxTtftMs: z.ZodOptional<z.ZodNumber>;
                minTokensPerSecond: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            bias: z.ZodOptional<z.ZodObject<{
                categories: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>>;
                forbid: z.ZodDefault<z.ZodArray<z.ZodString>>;
                maxHits: z.ZodOptional<z.ZodNumber>;
                maxCategoryHits: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        review: z.ZodOptional<z.ZodObject<{
            statement: z.ZodString;
            criteria: z.ZodDefault<z.ZodArray<z.ZodString>>;
            model: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** A validated suite (zod-inferred: every optional field resolved to an explicit shape). */
export type EvalSuite = z.infer<typeof SUITE>;
/** A validated case. */
export type EvalCase = z.infer<typeof CASE>;
/** One ordered tool-call expectation. */
export type ToolCallExpectation = z.infer<typeof TOOL_CALL_EXPECTATION>;
/** One tool-result expectation. */
export type ResultExpectation = z.infer<typeof RESULT_EXPECTATION>;
/** Final-output expectation. */
export type OutputExpectation = z.infer<typeof OUTPUT_EXPECTATION>;
/** Prompt-regression expectation. */
export type PromptExpectation = z.infer<typeof PROMPT_EXPECTATION>;
/** Stress-metric expectation. */
export type StressExpectation = z.infer<typeof STRESS_EXPECTATION>;
/** Fairness (bias-radar) expectation. */
export type BiasExpectation = z.infer<typeof BIAS_EXPECTATION>;
/** Suite schema (zod v4). */
export declare const SuiteSchema: z.ZodType<EvalSuite>;
/** The parsed-DSL file facts, for error messages and reporting. */
export interface ParsedSuite {
    /** The suite. */
    readonly suite: EvalSuite;
    /** The absolute source path, when the suite came from a file. */
    readonly sourcePath?: string;
}
/**
 * One DSL validation failure, carrying the exact YAML/validation message.
 * Parsing never throws for bad user input: it reports instead.
 */
export declare class DslError extends Error {
    constructor(message: string);
}
/**
 * Parse and validate one suite document (YAML text).
 * @param text - the YAML source.
 * @param sourcePath - optional path used in error messages.
 * @returns the validated suite.
 * @throws {DslError} on YAML syntax errors or schema violations.
 */
export declare function parseSuite(text: string, sourcePath?: string): EvalSuite;
/** The model/provider resolution table applied per run (see runner). */
export interface ResolvedModelTable {
    /** The provider route every case uses. */
    readonly provider: string;
    /** CLI-supplied default model, when present. */
    readonly cliModel?: string;
    /** CLI-supplied tier overrides, merged over suite tiers. */
    readonly cliTiers: Readonly<Record<string, string>>;
}
/**
 * Resolve one case's model id: case.model, then case.tier through the
 * merged tier table, then the suite default, then the CLI default.
 * Returns undefined when nothing resolves it — the runner rejects loudly
 * (no hardcoded model).
 * @param caze - the case.
 * @param suite - the owning suite.
 * @param table - the run's resolution table.
 * @returns the model id, or undefined.
 */
export declare function resolveCaseModel(caze: EvalCase, suite: EvalSuite, table: ResolvedModelTable): string | undefined;
/**
 * Resolve one case's timeout: case.timeoutMs, then suite.timeoutMs, then the
 * CLI default. Returns undefined when nothing resolves it — the runner
 * rejects loudly (no hardcoded timeout).
 * @param caze - the case.
 * @param suite - the owning suite.
 * @param cliTimeoutMs - the CLI-supplied default, when present.
 * @returns the timeout in milliseconds, or undefined.
 */
export declare function resolveCaseTimeout(caze: EvalCase, suite: EvalSuite, cliTimeoutMs?: number): number | undefined;
export {};
//# sourceMappingURL=dsl.d.ts.map