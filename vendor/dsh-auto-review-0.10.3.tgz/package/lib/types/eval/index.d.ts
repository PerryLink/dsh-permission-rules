/**
 * The dsh-eval engine face: YAML case DSL, trace collection, structured
 * assertions, second-model review, the isolated headless-session runner,
 * and the JSON/Markdown report writers. Library consumers compose these
 * directly; the `dsh-eval` CLI (`dsh-auto-review/eval-cli`) boots the
 * shipped `eval/cordis.yml` composition and drives the engine.
 * @module dsh-auto-review/eval
 */
export * from './dsl.js';
export * from './trace.js';
export * from './diff.js';
export * from './stress.js';
export * from './assert.js';
export * from './review.js';
export * from './runner.js';
export * from './report.js';
//# sourceMappingURL=index.d.ts.map