/**
 * Stress-metric computation for dsh-eval: pure functions over per-step
 * timing records collected by the trace fold. The `expect.stress` assertion
 * gates P99 step latency, time-to-first-token, and token generation speed —
 * the LLM-Stress-Test-CLI metrics — without any hardcoded thresholds (the
 * case declares its own).
 * @module dsh-auto-review/eval/stress
 */
import type { TraceStep } from './trace.js';
/** Percentile metrics and throughput of one case run. */
export interface StressMetrics {
    /** How many steps carried any timing. */
    readonly stepCount: number;
    /** 50th-percentile step latency (ms). */
    readonly p50Ms?: number;
    /** 90th-percentile step latency (ms). */
    readonly p90Ms?: number;
    /** 95th-percentile step latency (ms). */
    readonly p95Ms?: number;
    /** 99th-percentile step latency (ms). */
    readonly p99Ms?: number;
    /** Median time-to-first-token (ms). */
    readonly ttftMedianMs?: number;
    /** Worst time-to-first-token (ms). */
    readonly ttftMaxMs?: number;
    /** Aggregate token generation speed (output tokens per second). */
    readonly tokensPerSecond?: number;
}
/**
 * Nearest-rank percentile of a sorted ascending sample.
 * @param sorted - ascending sample.
 * @param p - percentile in (0, 100].
 * @returns the sample value at the requested percentile, or undefined for an
 *   empty sample.
 */
export declare function percentile(sorted: readonly number[], p: number): number | undefined;
/**
 * Compute stress metrics from the collected per-step timing records. Steps
 * without a start/end, start/first-token, or first/last-token window simply
 * do not contribute to the metric they cannot measure.
 * @param steps - the trace's per-step timing records.
 * @returns the owned metrics.
 */
export declare function computeStressMetrics(steps: readonly TraceStep[]): StressMetrics;
//# sourceMappingURL=stress.d.ts.map