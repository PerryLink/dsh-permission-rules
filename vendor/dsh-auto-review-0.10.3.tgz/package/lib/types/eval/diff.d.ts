/**
 * Prompt-regression diff: a pure, dependency-free line differ plus a
 * side-by-side renderer. The `expect.prompt` assertion compares the agent's
 * rendered system prompt against a committed baseline; any drift — the "one
 * word change breaks ten cases" failure mode — is reported here as a
 * two-column diff instead of a single opaque mismatch.
 * @module dsh-auto-review/eval/diff
 */
/** One aligned diff row: unchanged, a baseline-only removal, or an actual-only addition. */
export interface DiffRow {
    /** How this row changed. */
    readonly kind: 'unchanged' | 'removed' | 'added';
    /** The baseline-side text (absent for `added`). */
    readonly baseline?: string;
    /** The actual-side text (absent for `removed`). */
    readonly actual?: string;
}
/** Whether a diff carries any change. */
export declare function hasChanges(rows: readonly DiffRow[]): boolean;
/**
 * Diff two texts line by line. Rows are aligned by longest common
 * subsequence; a replaced region is emitted as its baseline removals
 * followed by its actual additions. Oversized inputs fall back to a naive
 * full-replace diff rather than allocating an unbounded table.
 * @param baseline - the committed baseline text.
 * @param actual - the captured system prompt text.
 * @returns the aligned diff rows.
 */
export declare function diffLines(baseline: string, actual: string): DiffRow[];
/**
 * Render a diff as an aligned two-column text block (baseline left, actual
 * right, `-`/`+` change markers). The prompt assertion attaches this to the
 * report so a drifted prompt reads as a reviewable diff.
 * @param rows - the diff rows.
 * @param leftLabel - the left column header.
 * @param rightLabel - the right column header.
 * @param width - per-column width in characters.
 * @returns the side-by-side text.
 */
export declare function renderSideBySide(rows: readonly DiffRow[], leftLabel?: string, rightLabel?: string, width?: number): string;
//# sourceMappingURL=diff.d.ts.map