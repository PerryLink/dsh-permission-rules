/**
 * The `dsh-eval` command: boots the shipped standalone evaluation
 * composition (`eval/cordis.yml` — Minimal persona, approval `never`,
 * workspace-write sandbox, read/write fs tools, subagent providers), loads
 * one or more YAML suites, and runs every case as an isolated headless
 * agent session through the {@link EvalEngine}.
 *
 * CI gate: the process exits 0 exactly when every case of every suite
 * passed; 1 otherwise; 2 on usage/configuration errors. `--no-gate` disables
 * the gate. SIGINT/SIGTERM abort the run (the second signal force-exits).
 * @module dsh-auto-review/eval-cli
 */
/** Parsed CLI flags. */
export interface CliFlags {
    readonly suitePaths: readonly string[];
    readonly provider?: string;
    readonly model?: string;
    readonly tiers: Readonly<Record<string, string>>;
    readonly timeoutMs?: number;
    readonly concurrency?: number;
    readonly out: string;
    readonly workspaceRoot?: string;
    readonly keepWorkspaces: boolean;
    readonly noMarkdown: boolean;
    readonly noGate: boolean;
    readonly reviewProvider?: string;
    readonly reviewModel?: string;
    readonly reviewTimeoutMs?: number;
}
/** CLI usage/validation error. */
export declare class CliError extends Error {
    constructor(message: string);
}
/** Parse the raw argv (without node/bin). */
export declare function parseFlags(argv: readonly string[]): CliFlags;
/** Control-flow marker for `--help`. */
export declare class HelpRequested extends Error {
    constructor();
}
/** Control-flow marker for `--version`. */
export declare class VersionRequested extends Error {
    constructor();
}
/**
 * Expand one suite path: files load directly, directories contribute their
 * `*.yaml`/`*.yml` children (sorted, for stable runs).
 */
export declare function resolveSuiteFiles(paths: readonly string[]): Promise<string[]>;
/** The path of the shipped evaluation composition (repo root in dev, package root when built). */
export declare function compositionPath(): string;
/**
 * The CLI entry: parse flags, boot the composition, run every suite, write
 * reports, and return the process exit code.
 * @param argv - raw arguments (defaults to process.argv.slice(2)).
 * @param io - process-facing streams (tests substitute captures).
 * @returns the exit code.
 */
export declare function main(argv?: readonly string[], io?: {
    stdout: NodeJS.WriteStream;
    stderr: NodeJS.WriteStream;
}): Promise<number>;
//# sourceMappingURL=cli.d.ts.map