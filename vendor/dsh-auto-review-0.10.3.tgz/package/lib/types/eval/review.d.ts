/**
 * The dsh-eval second-model review layer: a supplementary assertion over a
 * finished case run. It reuses the SAME subagent seam as the approval
 * reviewer (`ctx.subagents`, toolFilter allow-list, structured output
 * schema, timeout + abort racing) but with an evaluation-specific prompt —
 * one sentence of role statement first, kept short — and a
 * `{ pass, reason }` verdict.
 *
 * The review is an assertion layer, not a replacement for the structured
 * assertions: both verdicts land in the report, and either failing fails
 * the case.
 * @module dsh-auto-review/eval/review
 */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { Context } from '@deepseek-ai/cordis';
import { type ObjectJsonSchema } from '@deepseek-ai/dsh-tools';
import type { EvalCase } from './dsl.js';
import type { CaseTrace } from './trace.js';
/** A second-model evaluation verdict. */
export interface EvalReviewVerdict {
    readonly pass: boolean;
    readonly reason: string;
}
/** Why the review produced no verdict. */
export type EvalReviewFailureKind = 'timeout' | 'cancelled' | 'unavailable' | 'schema';
/** A review that produced no verdict. */
export interface EvalReviewFailure {
    readonly failure: EvalReviewFailureKind;
    readonly error: string;
    readonly model?: string;
    readonly reviewerSessionId?: string;
}
/** The closed result of one evaluation review. */
export type EvalReviewResolution = EvalReviewVerdict | EvalReviewFailure;
/** Distinguish a verdict from a failure. */
export declare function isEvalReviewFailure(resolution: EvalReviewResolution): resolution is EvalReviewFailure;
/** Object-rooted evaluation verdict schema enforced on the child's structured_output capture. */
export declare const EVAL_VERDICT_SCHEMA: ObjectJsonSchema;
/** The engine-side review configuration (reuses the approval-reviewer knobs). */
export interface EvalReviewConfig {
    /** Subagent provider name for the reviewer. */
    readonly reviewerProvider: string;
    /** Reviewer model id; unset inherits the case agent's route. */
    readonly reviewerModel?: string | undefined;
    /** Verdict deadline in milliseconds. */
    readonly reviewerTimeoutMs: number;
    /** Reviewer tool allow-list (read-only tools). */
    readonly reviewerTools: readonly string[];
}
/**
 * Build the evaluation review prompt: one sentence of role statement, then
 * the case task, the expected behavior, and the actual evidence (final
 * output and compact tool-call trace), then the verdict contract.
 * @param caze - the case under review.
 * @param trace - the collected trace.
 * @returns the exact prompt text block.
 */
export declare function buildEvalReviewPrompt(caze: EvalCase, trace: CaseTrace): string;
/**
 * Run one evaluation review: a one-shot reviewer child on the configured
 * provider, raced against the timeout and the run's cancellation signal.
 * Every failure path resolves to an {@link EvalReviewFailure} — the caller
 * records it and marks the case `error` (a review is part of the case
 * definition; an unavailable reviewer cannot be silently skipped).
 * @param ctx - the engine context (`ctx.subagents`).
 * @param config - the review configuration.
 * @param parent - the still-live case agent (the reviewer's parent).
 * @param caze - the case.
 * @param trace - the collected trace.
 * @param signal - the run's cancellation signal.
 * @returns the verdict or the failure.
 */
export declare function runEvalReview(ctx: Context, config: EvalReviewConfig, parent: Agent, caze: EvalCase, trace: CaseTrace, signal: AbortSignal): Promise<EvalReviewResolution>;
//# sourceMappingURL=review.d.ts.map