/**
 * The structured assertion engine of dsh-eval: pure functions that check a
 * collected {@link CaseTrace} against a case's `expect` block. Every
 * assertion reports its own pass/fail with the expected and actual values,
 * so reports can explain WHY a case failed without rerunning it.
 * @module dsh-auto-review/eval/assert
 */
import type { EvalCase, ToolCallExpectation } from './dsl.js';
import type { CaseTrace } from './trace.js';
/** One evaluated assertion. */
export interface AssertionResult {
    /** Stable id inside the case (`toolCalls[0]`, `results[1]`, `output.contains`, …). */
    readonly id: string;
    /** Human-readable assertion kind. */
    readonly kind: string;
    readonly passed: boolean;
    /** Human-readable expectation, rendered from the DSL. */
    readonly expected: string;
    /** Human-readable actual state. */
    readonly actual: string;
    /** Optional multi-line detail (a side-by-side prompt diff, a bias radar). */
    readonly detail?: string;
}
/** Whether a tool-name pattern matches an actual tool name (exact or `*` suffix wildcard). */
export declare function toolNameMatches(pattern: string, actual: string): boolean;
/**
 * Deep-partial containment: every leaf of `expected` must exist in `actual`.
 * Object keys recurse, arrays match index-wise, and a string leaf matches
 * when the actual value is a string CONTAINING it (substring semantics — the
 * natural reading of `contains: {file_path: "config.ts"}` over the actual
 * `"src/config.ts"`); use `equals` for exact string matching.
 */
export declare function deepContains(actual: unknown, expected: unknown): boolean;
/** Regex argument matching: every key's actual string value must match the expected regex. */
export declare function argumentsMatchRegexes(actual: unknown, expected: Record<string, string>): boolean;
/** Render one argument expectation compactly. */
export declare function renderArgumentExpectation(expectation: ToolCallExpectation['arguments']): string;
/**
 * Compile-time validation of a case's expectation block: every regex must be
 * valid JavaScript (the engine fails the suite loudly instead of failing
 * each assertion at run time). Throws a TypeError on the first bad regex.
 * @param caze - the validated case.
 */
export declare function validateExpectations(caze: EvalCase): void;
/**
 * Run every structured assertion of one case against its trace. Review
 * assertions live in a separate layer (see `review.ts`).
 * @param caze - the case (expectations).
 * @param trace - the collected trace.
 * @returns one result per assertion, in definition order.
 */
export declare function runAssertions(caze: EvalCase, trace: CaseTrace, promptBaselines?: ReadonlyMap<string, string>): AssertionResult[];
//# sourceMappingURL=assert.d.ts.map