/**
 * Scoped stylesheet for the review panel. Standalone bundles cannot use the
 * in-repo CSS-module pipeline, so the panel injects one `<style>` element
 * whose selectors are all scoped under `[data-dsh-auto-review]`.
 * @module dsh-auto-review/client/styles
 */
/** Install the scoped stylesheet once per plugin fiber. */
export declare function installPanelStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map