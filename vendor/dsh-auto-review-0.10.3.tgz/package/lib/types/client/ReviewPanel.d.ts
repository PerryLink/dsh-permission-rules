/**
 * The session-header review panel: a button in the conversation header that
 * opens a popover with this session's auto-review state — the on/off switch,
 * budgets, cumulative statistics (including hard-disable rejections and
 * cache hits), the circuit trip, recent verdicts, and one-shot approve
 * buttons for recent denials. Data arrives through the `autoReview` session
 * projection; switches and approves execute the `/auto-review` command
 * through the commands Remote.
 * @module dsh-auto-review/client/ReviewPanel
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.js';
/** Registration-side injected face: the approve action for one recent denial. */
export interface ReviewPanelInjected {
    /** Approve the n-th most recent denial (1 = most recent); resolves with the command result text. */
    approve: (n: number) => Promise<string>;
    /** Switch the session's auto-review on/off (`/auto-review on|off`); resolves with the command result text. */
    setEnabled: (enabled: boolean) => Promise<string>;
}
/** Full component props assembled by the session-header slot renderer. */
export type ReviewPanelProps = PropsRuntime<'conversation.session.header.actions'> & PropsLocale<typeof NS> & InjectFace<ReviewPanelInjected> & {
    readonly useProjection?: unknown;
};
/**
 * Render the review panel action.
 * @param props - framework kit (sessionId, useProjection), locale, and the approve face.
 * @returns the header button with its popover.
 */
export declare function ReviewPanel({ useProjection, approve, setEnabled, t }: ReviewPanelProps): ReactNode;
//# sourceMappingURL=ReviewPanel.d.ts.map