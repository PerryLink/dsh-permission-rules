/**
 * Package-owned invariant companion for `dsh-auto-review`:
 *
 * 1. Every `autoReview/verdict` audit event references an `approval/asked`
 *    event that precedes it in the same session, at most one verdict exists
 *    per asked event, and payload fields obey the closed vocabularies
 *    (decision/reason/riskLevel/outcome/fallback). The same chain holds for
 *    `autoReview/rejection` events (hard-disable rejections).
 * 2. Model-visible ⟺ logged: every `tool/result` carrying the deny marker
 *    links to a recorded `deny` verdict with a matching call id, every
 *    `tool/result` carrying the fallback marker links to a recorded fallback
 *    verdict that was rejected, and every `tool/result` carrying the never
 *    marker links to a recorded rejection that settled rejected.
 *
 * @module dsh-auto-review/invariant
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "auto-review-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map