/**
 * Standalone deterministic review path for the stdio MCP server export.
 *
 * The in-process reviewer (`src/review.ts`) needs the harness subagent seam
 * and a second model, which a separate stdio process cannot reach. This module
 * is the independent verdict path: it reuses the same-fingerprint verdict
 * cache (`src/cache.ts`) and the risk-rule / tool-policy resolution
 * (`src/config.ts`), and settles deterministically:
 *
 * - a `never` risk rule or tool override → `deny` with the matched source;
 * - a cache hit on an identical `tool + arguments` fingerprint → replays that
 *   verdict (the only way an `allow` can surface in a standalone process);
 * - everything else (`ai` needs a model, `human` needs a human) → fail-closed
 *   `deny` with `reason: "standalone path, no model"`.
 *
 * The path is read-only and deterministic: no network, no model, no write.
 * @module dsh-auto-review/mcp/standalone
 */
import type { ResolvedConfig, RiskLevel } from '../config.js';
/** One standalone review request: the tool plus its (optional) arguments and reason. */
export interface StandaloneReviewInput {
    readonly tool: string;
    readonly args?: unknown;
    readonly reason?: string;
}
/** The deterministic verdict a standalone review always returns (deny unless a cache hit replays). */
export interface StandaloneVerdict {
    readonly decision: 'allow' | 'deny';
    readonly reason: string;
    readonly riskLevel: RiskLevel;
    /** True when the verdict was replayed from the same-fingerprint cache. */
    readonly cached?: boolean;
}
/** The cache_stats tool result: counters plus the TTL configuration. */
export interface CacheStats {
    readonly hits: number;
    readonly stores: number;
    readonly size: number;
    readonly ttlMs: number;
    readonly enabled: boolean;
}
/**
 * The standalone reviewer: a TTL-bounded same-fingerprint cache plus the
 * deterministic policy resolution. Constructed once per process; `review`
 * is synchronous and side-effect free except for cache writes.
 */
export declare class StandaloneReviewer {
    readonly config: ResolvedConfig;
    private readonly cache;
    constructor(config: ResolvedConfig);
    /**
     * Deterministically review one action.
     * @param input - `{tool, args?, reason?}`.
     * @returns the verdict (fail-closed deny unless a rule or cache says otherwise).
     */
    review(input: StandaloneReviewInput): StandaloneVerdict;
    /** Cache counters and TTL status for the `cache_stats` tool. */
    cacheStats(): CacheStats;
}
/**
 * Build the resolved standalone config from environment variables, reusing
 * `resolveConfig` (so risk-rule regexes compile with the exact same flag
 * semantics and misconfiguration fails loud).
 *
 * - `DSH_AUTO_REVIEW_RISK_RULES` — JSON array of `{pattern, policy, field?}`.
 * - `DSH_AUTO_REVIEW_TOOLS_POLICY` — JSON `{default?, overrides?}`.
 * - `DSH_AUTO_REVIEW_CACHE_TTL_MS` / `DSH_AUTO_REVIEW_CACHE_MAX_ENTRIES` — cache knobs.
 * @param env - process environment (test-injectable).
 * @returns the resolved config.
 */
export declare function resolveEnvConfig(env?: NodeJS.ProcessEnv): ResolvedConfig;
//# sourceMappingURL=standalone.d.ts.map