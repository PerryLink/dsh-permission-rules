/**
 * JSON-RPC 2.0 / MCP transport for the standalone review server: a stdio
 * loop speaking newline-delimited JSON (NDJSON). Exposes two tools —
 * `review_action` (deterministic verdict) and `cache_stats` (cache counters).
 * No Content-Length framing is supported; the wire format is one JSON object
 * per line. This module owns only the protocol dispatch — every decision
 * lives in {@link StandaloneReviewer}.
 * @module dsh-auto-review/mcp/server
 */
import type { StandaloneReviewer } from './standalone.js';
/** MCP server name (initialize's `serverInfo.name`). */
export declare const MCP_SERVER_NAME = "dsh-auto-review";
/** The MCP protocol version this export speaks. */
export declare const MCP_PROTOCOL_VERSION = "2025-06-18";
/** The MCP server surface: a JSON-RPC dispatcher plus its tool list. */
export interface McpServer {
    /** Dispatch one parsed JSON-RPC message; returns a response object or null for notifications. */
    readonly handle: (message: unknown) => Record<string, unknown> | null;
    readonly tools: ReadonlyArray<{
        name: string;
        description: string;
        inputSchema: Record<string, unknown>;
    }>;
}
/**
 * Assemble the MCP server around a reviewer.
 * @param reviewer - the deterministic standalone reviewer.
 * @param version - the package version reported in `initialize`.
 * @returns the dispatcher and tool list.
 */
export declare function createMcpServer(reviewer: StandaloneReviewer, version: string): McpServer;
/**
 * Run the NDJSON transport on stdio: one JSON object per line in, one response
 * per request out. Notifications and blank lines are skipped; unparseable
 * input produces a `-32700` parse-error response.
 * @param server - the dispatcher from {@link createMcpServer}.
 * @param io - injectable stdin/stdout for tests; defaults to the real process.
 * @returns a disposer that closes the readline interface.
 */
export declare function runStdioServer(server: McpServer, io?: {
    stdin?: NodeJS.ReadableStream;
    stdout?: NodeJS.WritableStream;
}): () => void;
//# sourceMappingURL=server.d.ts.map