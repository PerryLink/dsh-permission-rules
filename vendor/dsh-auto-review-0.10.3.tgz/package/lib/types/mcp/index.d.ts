/**
 * The stdio MCP server export entry: the deterministic standalone reviewer
 * plus the JSON-RPC transport. Bundled to `lib/mcp.js`; launched by
 * `bin/dsh-auto-review-mcp.mjs`.
 * @module dsh-auto-review/mcp
 */
export { StandaloneReviewer, resolveEnvConfig, } from './standalone.js';
export type { StandaloneReviewInput, StandaloneVerdict, CacheStats, } from './standalone.js';
export { createMcpServer, runStdioServer, MCP_SERVER_NAME, MCP_PROTOCOL_VERSION, } from './server.js';
export type { McpServer } from './server.js';
//# sourceMappingURL=index.d.ts.map