/**
 * The reviewer subagent: one-shot in-process child with a read-only tool
 * allow-list and a structured verdict schema, raced against the configured
 * timeout and the request's cancellation signal. Any failure resolves to a
 * {@link ReviewFailure} — the caller applies the fallback policy, never a
 * grant (fail closed by default).
 * @module dsh-auto-review/review
 */
import type { Context } from '@deepseek-ai/cordis';
import type { CallId } from './call-id.js';
import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session';
import type { ApprovalRequest } from '@deepseek-ai/dsh-user-approval';
import { type ObjectJsonSchema } from '@deepseek-ai/dsh-tools';
import type { AutoReviewFallback } from './events.js';
import { AutoReviewCircuitId, AutoReviewRejectionId, AutoReviewVerdictId } from './events.js';
import type { ContextBudgetConfig, ResolvedConfig, RiskLevel } from './config.js';
import type { ReviewerChildren } from './isolation.js';
/** A reviewer verdict, validated against the closed decision vocabulary. */
export interface ReviewerVerdict {
    readonly decision: 'allow' | 'deny';
    readonly reason: string;
    readonly riskLevel?: RiskLevel;
    /** The reviewer child's session id (its own log is auditable). */
    readonly reviewerSessionId?: SessionId;
    /** The explicitly configured reviewer model, when one was set. */
    readonly model?: string;
}
/**
 * A review that produced no verdict. The caller maps the failure to the
 * configured fallback policy.
 */
export interface ReviewFailure {
    readonly fallback: AutoReviewFallback;
    readonly error: string;
    readonly reviewerSessionId?: SessionId;
    readonly model?: string;
}
/** The closed result of one review attempt. */
export type ReviewResolution = ReviewerVerdict | ReviewFailure;
/** Distinguish a verdict resolution from a failure. */
export declare function isReviewFailure(resolution: ReviewResolution): resolution is ReviewFailure;
/** Object-rooted verdict schema enforced on the child's structured_output capture. */
export declare const VERDICT_SCHEMA: ObjectJsonSchema;
/**
 * Recursively redact sensitive values from a JSON value: any object key
 * matching {@link SENSITIVE_KEY_PATTERN} has its value replaced.
 * @param value - the detached JSON value to sanitize.
 * @returns a detached copy with sensitive values redacted.
 */
export declare function sanitizeArguments(value: unknown): unknown;
/**
 * The already-presented call arguments, parsed and key-redacted, as pretty
 * JSON — the raw material for both the reviewer prompt section and the
 * `arguments` risk-rule field.
 * @param events - the requesting session's log.
 * @param callId - the call to render.
 * @returns the sanitized JSON text, or undefined when the log lacks a parseable call.
 */
export declare function sanitizedArgumentsText(events: readonly SessionEvent[], callId: CallId): string | undefined;
/**
 * Render the tool-call context for the reviewer: the already-streamed call
 * arguments (parsed, redacted, truncated) or a note when the log lacks them.
 * @param events - the requesting session's log.
 * @param callId - the call to render.
 * @param maxChars - the preview cap (shared with reason truncation).
 * @returns the prompt section text.
 */
export declare function renderCallContext(events: readonly SessionEvent[], callId: CallId | undefined, maxChars: number): string;
/**
 * Build the compact-transcript section for the reviewer: the tail of the
 * session's user/assistant messages and tool calls/results, most recent
 * last, bounded by {@link ContextBudgetConfig}. `turns: 0` yields an empty
 * section. Tool-call arguments and tool-result text enter verbatim (they are
 * already-presented transcript content); the presented call of the pending
 * request is redacted separately in {@link renderCallContext}.
 *
 * The character budget is spent from the NEWEST line backwards, so an
 * over-budget transcript loses its oldest lines. Truncating the joined text
 * instead would cut the tail — the open turn that carries the user's request
 * and the reasoning behind the pending call, which is exactly the evidence
 * the verdict rules ask for.
 * @param events - the requesting session's log.
 * @param budget - how much context to include.
 * @returns the prompt section text (empty when disabled).
 */
export declare function buildContextSection(events: readonly SessionEvent[], budget: ContextBudgetConfig): string;
/** Context of a pending human override, passed into the reviewer prompt. */
export interface OverrideContext {
    readonly reviewId: AutoReviewVerdictId;
    readonly toolName: string;
}
/**
 * Truncate a string to a character budget without cutting surrogate pairs.
 * @param text - the string to cap.
 * @param maxChars - the positive budget.
 * @returns the capped string.
 */
export declare function truncate(text: string, maxChars: number): string;
/**
 * Build the reviewer prompt: role, the pending request's tool/reason/context/
 * workspace, the resolved risk rules, the ruling policy text, the optional
 * human-override context, and the verdict contract.
 * @param request - the pending approval request.
 * @param config - resolved config (rules, guidance, budgets).
 * @param override - a pending human one-shot override, when one applies.
 * @returns the exact prompt text block.
 */
export declare function buildReviewPrompt(request: ApprovalRequest, config: ResolvedConfig, override?: OverrideContext): string;
/**
 * Validate the provider-validated structured capture against the closed
 * verdict vocabulary. The subagent seam validates against the schema, but its
 * result is typed `unknown`; this is the boundary that narrows it.
 * @param value - the captured structured value.
 * @param reasonMaxChars - the reason cap.
 * @returns the verdict, or undefined when the value cannot be a verdict.
 */
export declare function parseVerdict(value: unknown, reasonMaxChars: number): ReviewerVerdict | undefined;
/**
 * Run one review attempt: start a one-shot reviewer child on the configured
 * provider, await its structured verdict, and race both the configured
 * timeout and the request signal. Every failure path resolves to a
 * {@link ReviewFailure} — never to a grant.
 * @param ctx - the plugin context (`ctx.subagents` and the request's parent agent).
 * @param config - resolved config (provider, timeout, tools, model, budgets).
 * @param request - the pending approval request (parent, signal, and evidence).
 * @param reviewerSessions - the mount's reviewer-child registry, so the
 *   answerer can refuse the child's own approval asks while the review runs
 *   and the context firewall knows whose steps to strip.
 * @param override - a pending human one-shot override, when one applies.
 * @returns the verdict or the failure.
 */
export declare function runReview(ctx: Context, config: ResolvedConfig, request: ApprovalRequest, reviewerSessions: ReviewerChildren, override?: OverrideContext): Promise<ReviewResolution>;
/**
 * Mint one verdict id. Wrapped for testability (audit uniqueness is a UUID).
 * @returns a fresh branded id.
 */
export declare function newVerdictId(): AutoReviewVerdictId;
/**
 * Mint one circuit-trip id. Wrapped for testability (audit uniqueness is a UUID).
 * @returns a fresh branded id.
 */
export declare function newCircuitId(): AutoReviewCircuitId;
/**
 * Mint one hard-disable rejection id. Wrapped for testability (audit
 * uniqueness is a UUID).
 * @returns a fresh branded id.
 */
export declare function newRejectionId(): AutoReviewRejectionId;
//# sourceMappingURL=review.d.ts.map