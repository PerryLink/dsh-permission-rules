/**
 * The session-header review panel: a button in the conversation header that
 * opens a popover with this session's auto-review state — budgets, cumulative
 * statistics, the circuit trip, recent verdicts, and one-shot approve
 * buttons for recent denials. Data arrives through the `autoReview`
 * session projection; approves execute the `/auto-review approve [n]`
 * command through the commands Remote.
 * @module dsh-auto-review/client/ReviewPanel
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
/** Registration-side injected face: the approve action for one recent denial. */
export interface ReviewPanelInjected {
    /** Approve the n-th most recent denial (1 = most recent); resolves with the command result text. */
    approve: (n: number) => Promise<string>;
}
/** Full component props assembled by the session-header slot renderer. */
export type ReviewPanelProps = PropsRuntime<'conversation.session.header.actions'> & PropsLocale<typeof NS> & InjectFace<ReviewPanelInjected>;
/**
 * Render the review panel action.
 * @param props - framework kit (sessionId, useProjection), locale, and the approve face.
 * @returns the header button with its popover.
 */
export declare function ReviewPanel({ useProjection, approve, t }: ReviewPanelProps): ReactNode;
//# sourceMappingURL=ReviewPanel.d.ts.map