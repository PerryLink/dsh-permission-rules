/**
 * Host projection unit for the `autoReview` panel value: folds the log-only
 * `autoReview/*` events into one wire-JSON whole value the browser review
 * panel reads via `useProjection('autoReview')`. Pure mathematics only — the
 * framework owns subscriptions, watermarks, change feeds, and persistence.
 * The fold mirrors the `events.ts` pure folds (budgets, statistics, denials).
 * @module dsh-auto-review/projection
 */
import { z } from 'zod';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { AutoReviewDenyView, AutoReviewProjection, AutoReviewVerdictView } from './projection-types.ts';
/** Strict wire schema — validates the `view` output before it leaves the host. */
export declare const AUTO_REVIEW_PROJECTION_SCHEMA: z.ZodObject<{
    enabled: z.ZodBoolean;
    verdictsUsed: z.ZodNumber;
    failuresUsed: z.ZodNumber;
    allows: z.ZodNumber;
    denies: z.ZodNumber;
    fallbacks: z.ZodNumber;
    avgDurationMs: z.ZodNumber;
    circuit: z.ZodNullable<z.ZodObject<{
        action: z.ZodUnion<readonly [z.ZodLiteral<"delegate">, z.ZodLiteral<"reject">, z.ZodLiteral<"abort-turn">]>;
        trip: z.ZodObject<{
            kind: z.ZodUnion<readonly [z.ZodLiteral<"consecutive">, z.ZodLiteral<"window">]>;
            count: z.ZodNumber;
        }, z.core.$strip>;
        toolName: z.ZodString;
    }, z.core.$strip>>;
    recent: z.ZodArray<z.ZodObject<{
        reviewId: z.ZodString;
        toolName: z.ZodString;
        at: z.ZodNumber;
        durationMs: z.ZodNumber;
        decision: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<"allow">, z.ZodLiteral<"deny">]>>;
        riskLevel: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<"low">, z.ZodLiteral<"medium">, z.ZodLiteral<"high">]>>;
        escalation: z.ZodOptional<z.ZodLiteral<"risk-policy">>;
        fallback: z.ZodOptional<z.ZodString>;
        outcome: z.ZodOptional<z.ZodUnion<readonly [z.ZodLiteral<"allowed-once">, z.ZodLiteral<"rejected">, z.ZodLiteral<"cancelled">, z.ZodLiteral<"unavailable">]>>;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    recentDenies: z.ZodArray<z.ZodObject<{
        reviewId: z.ZodString;
        toolName: z.ZodString;
        reason: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** The fold's plain-JSON state (the persisted-cache precondition). */
export interface AutoReviewProjectionState {
    readonly enabled: boolean;
    readonly turnOpen: boolean;
    readonly verdictsUsed: number;
    readonly failuresUsed: number;
    readonly allows: number;
    readonly denies: number;
    readonly fallbacks: number;
    readonly durationSum: number;
    readonly decided: number;
    readonly circuit: AutoReviewProjection['circuit'];
    readonly recent: readonly AutoReviewVerdictView[];
    readonly recentDenies: readonly AutoReviewDenyView[];
}
/** State for the empty log. */
export declare function initAutoReviewProjection(): AutoReviewProjectionState;
/**
 * Pure transition: previous state + one committed event → next state.
 * Uninterested events return the same state reference.
 * @param state - the state covering all prior events.
 * @param event - the next committed session event.
 * @returns the next state (same reference when the event is not this unit's).
 */
export declare function applyAutoReview(state: AutoReviewProjectionState, event: SessionEvent): AutoReviewProjectionState;
/** State → wire payload (the read-side projection). */
export declare function viewAutoReview(state: AutoReviewProjectionState): AutoReviewProjection;
/** The registered unit (see `ctx.sessionProjections.register`). */
export declare const AUTO_REVIEW_PROJECTION: ProjectionDefinition<'autoReview', AutoReviewProjectionState>;
//# sourceMappingURL=projection.d.ts.map