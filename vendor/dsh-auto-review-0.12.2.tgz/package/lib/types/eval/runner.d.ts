/**
 * The dsh-eval runner: executes a validated suite as isolated headless
 * agent sessions (one fresh agent + scratch workspace per case, mirroring
 * the official `dsh --profile headless` driver: `ctx.agents.create` →
 * `followup` → `whenIdle` → session flush), collects the tool-call trace
 * from the session event log, runs the structured assertions, then the
 * optional second-model review as a supplementary assertion layer.
 *
 * Engineering contracts:
 * - Per-case cancellation: a run-level `AbortSignal` stops scheduling and
 *   aborts active turns; a per-case timeout cancels only that agent.
 * - Concurrency: a worker pool bounded by the configured cap.
 * - No hardcoded model/timeout defaults: the runner validates every case's
 *   model and timeout resolution BEFORE starting any agent and fails the
 *   suite loudly on a case that resolves neither.
 * - Isolation: fresh session id, fresh scratch cwd, no cross-case state.
 * @module dsh-auto-review/eval/runner
 */
import type { Context } from '@deepseek-ai/cordis';
import type { AgentHandle } from '@deepseek-ai/dsh-agent';
import type { SessionHeader, SessionEvent } from '@deepseek-ai/dsh-session';
import type { ResolvedConfig } from '../config.js';
import type { AssertionResult } from './assert.js';
import type { EvalSuite } from './dsl.js';
import type { CaseTrace } from './trace.js';
import type { EvalReviewConfig } from './review.js';
/** One case's terminal status. */
export type CaseStatus = 'pass' | 'fail' | 'error' | 'cancelled';
/** The second-model review record inside a case result. */
export interface CaseReviewRecord {
    readonly provider: string;
    readonly model?: string;
    readonly reviewerSessionId?: string;
    readonly durationMs: number;
    readonly pass?: boolean;
    readonly reason?: string;
    readonly failure?: string;
    readonly error?: string;
}
/** The owned result of one executed case (everything the report needs). */
export interface CaseResult {
    readonly id: string;
    readonly description?: string;
    readonly status: CaseStatus;
    readonly provider: string;
    readonly model: string;
    readonly timeoutMs: number;
    readonly durationMs: number;
    readonly sessionId?: string;
    readonly workspace?: string;
    readonly timedOut?: boolean;
    readonly cancelled?: boolean;
    readonly error?: string;
    readonly assertions: readonly AssertionResult[];
    readonly review?: CaseReviewRecord;
    readonly trace: CaseTrace;
    /** Report-relative path of the owned trace JSON, when written. */
    readonly tracePath?: string;
    /** Report-relative path of the replayable session JSONL, when written. */
    readonly sessionLogPath?: string;
    /** The case input, truncated for reports. */
    readonly input: string;
}
/** Progress notification emitted while a suite runs. */
export interface EvalProgress {
    readonly suite: string;
    readonly caseId: string;
    readonly index: number;
    readonly total: number;
    readonly status: CaseStatus;
}
/** Everything the engine needs to run one suite. */
export interface EvalRunOptions {
    /** Provider route every case uses. */
    readonly provider: string;
    /** CLI-supplied default model (suite/case resolution beats it). */
    readonly cliModel?: string;
    /** CLI-supplied tier overrides. */
    readonly cliTiers?: Readonly<Record<string, string>>;
    /** CLI-supplied default timeout (suite/case resolution beats it). */
    readonly cliTimeoutMs?: number;
    /** Worker pool size (≥ 1). */
    readonly concurrency: number;
    /** Run-level cancellation: aborts active cases and stops scheduling. */
    readonly signal: AbortSignal;
    /** Directory scratch workspaces are created under. */
    readonly workspaceRoot: string;
    /** Suite-file directory, the anchor for relative `case.seedFrom` paths. */
    readonly suiteDir?: string;
    /** Keep scratch workspaces after the run (debugging); default false. */
    readonly keepWorkspaces?: boolean;
    /** Directory per-case trace artifacts are written under (relative links land in reports). */
    readonly traceDir?: string;
    /** Report-relative base for trace links (default `traces`). */
    readonly traceLinkBase?: string;
    /** Progress callback, one call per finished case. */
    readonly onProgress?: (progress: EvalProgress) => void;
}
/** The owned result of one suite run. */
export interface SuiteReport {
    readonly suite: string;
    readonly description?: string;
    readonly provider: string;
    readonly concurrency: number;
    readonly startedAt: number;
    readonly finishedAt: number;
    readonly durationMs: number;
    readonly summary: {
        readonly total: number;
        readonly pass: number;
        readonly fail: number;
        readonly error: number;
        readonly cancelled: number;
    };
    readonly cases: readonly CaseResult[];
}
/** The engine-facing review configuration, derived from the plugin config. */
export declare function evalReviewConfig(config: ResolvedConfig): EvalReviewConfig;
/**
 * Resolve every `expect.prompt` baseline into its text: inline `baseline`
 * passes through, and `baselineFrom` is read relative to the suite file (or
 * as an absolute path). A missing/unreadable file fails loudly BEFORE any
 * agent runs — a prompt-regression case whose baseline cannot load is a
 * configuration error, not a silent skip.
 * @param suite - the validated suite.
 * @param suiteDir - the suite-file directory (anchor for relative paths).
 * @returns a case-id → baseline-text map.
 */
export declare function resolvePromptBaselines(suite: EvalSuite, suiteDir?: string): Promise<ReadonlyMap<string, string>>;
/**
 * Serialize one session header as the persistence-backend header line.
 *
 * The physical header vocabulary is line-specific: the 0.1.2 (V0) line
 * records the inherited prefix length as `seedLength` and has no `isSeeded`,
 * while the V2/V3 lines require `isSeeded` and reject any unknown key — so a
 * V3 header must never carry `seedLength` (the seed cut is derived from the
 * log's `session/end-seed` marker instead). Emit the keys of the header's own
 * format version so an artifact written on one line stays readable on it.
 * @param header - the session header.
 * @param inheritedEventCount - the inherited prefix length (V0 `seedLength`).
 * @returns the header-line record.
 */
export declare function sessionHeaderLine(header: SessionHeader, inheritedEventCount?: unknown): Record<string, unknown>;
/**
 * Render one case's events as the canonical replayable session JSONL body
 * (header line + packed chunk rows — the exact on-disk vocabulary of the
 * harness session persistence backend). Trailing newline included.
 * @param header - the session header.
 * @param events - the full session log.
 * @returns the artifact text.
 */
export declare function renderSessionArtifact(header: SessionHeader, events: readonly SessionEvent[], inheritedEventCount?: unknown): string;
/**
 * The suite executor. One engine instance per process; the constructor only
 * captures the context and configuration — no side effects until
 * {@link runSuite}.
 */
export declare class EvalEngine {
    private readonly ctx;
    private readonly reviewConfig;
    /** Test seam: replace agent creation. Defaults to the real registry factory. */
    createAgent: (workspace: string, provider: string, model: string, maxTokens: number | undefined, signal: AbortSignal) => Promise<AgentHandle>;
    constructor(ctx: Context, reviewConfig: EvalReviewConfig);
    /** The real creation path (mirrors the official headless runner). */
    private defaultCreateAgent;
    /**
     * Run one suite. Resolves every case's model and timeout BEFORE starting
     * any agent; a case that resolves neither throws (configuration error,
     * never a silent default).
     * @param suite - the validated suite.
     * @param options - the run options.
     * @returns the owned suite report.
     */
    runSuite(suite: EvalSuite, options: EvalRunOptions): Promise<SuiteReport>;
    /** A cancelled case placeholder. */
    private cancelledResult;
    /** Execute one case end to end. */
    private runCase;
    /** Flush the session's durability backend (the replay artifact), when mounted. */
    private flushSession;
    /**
     * Write the per-case trace artifacts under the configured trace directory:
     * an owned trace JSON (the report's machine data) and the canonical
     * replayable session JSONL. Failures are non-fatal (the report still
     * carries the in-memory trace).
     * @returns report-relative paths of the artifacts that were written.
     */
    private writeTraceArtifacts;
    /**
     * Wait for the agent to reach quiescence, raced against the per-case
     * timeout and the run signal. On timeout the agent is cancelled (the turn
     * records `aborted` and the case fails with `timedOut`); on run abort the
     * caller's dispose path stops the loop.
     * @returns the race outcome.
     */
    private awaitIdle;
    /** Run the second-model review for one case (the agent is still live). */
    private runReview;
}
/**
 * Render a compact one-line summary of one case result (CLI progress,
 * report headers). Pure over owned report data.
 * @param result - the case result.
 * @returns the summary line.
 */
export declare function summarizeCaseResult(result: CaseResult): string;
//# sourceMappingURL=runner.d.ts.map