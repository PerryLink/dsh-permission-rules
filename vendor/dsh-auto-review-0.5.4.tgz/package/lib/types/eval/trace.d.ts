/**
 * Trace collection for dsh-eval: fold one agent session's durable event log
 * (from an anchor sequence) into an owned, JSON-serializable case trace —
 * tool-call/result pairs, the final assistant text, summed token usage, the
 * final turn outcome, and the last request header (system prompt + tool
 * catalog). Pure functions over `readonly SessionEvent[]`; no live DSH
 * references survive into the returned values.
 * @module dsh-auto-review/eval/trace
 */
import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session';
/** One collected tool invocation: the call and, when present, its paired result. */
export interface ToolCallRecord {
    /** The call id pairing `tool/call` and `tool/result`. */
    readonly callId: string;
    /** The requested tool name. */
    readonly name: string;
    /** The raw arguments JSON exactly as the model produced it. */
    readonly arguments: string;
    /** The parsed arguments, when they are valid JSON. */
    readonly argumentsJson?: unknown;
    /** The paired result, when the log has it. */
    readonly result?: {
        /** The concatenated text of the result message's content blocks. */
        readonly text: string;
        /** Whether the result carries an error identity. */
        readonly isError: boolean;
        /** The structured error identity, when the log recorded one. */
        readonly error?: {
            name: string;
            code: string;
        };
    };
}
/** Summed token accounting across the traced interval. */
export interface TraceTokenUsage {
    readonly inputTokens: number;
    readonly outputTokens: number;
    readonly cacheReadTokens: number;
    readonly cacheWriteTokens: number;
    readonly reasoningTokens: number;
}
/** Owned copy of one turn-end reason (unknown kinds degrade to a label). */
export type TraceTurnEnd = {
    kind: 'completed';
} | {
    kind: 'aborted';
} | {
    kind: 'blocked';
} | {
    kind: 'error';
    code: string;
    message: string;
} | {
    kind: 'max-tokens';
} | {
    kind: 'interrupted';
} | {
    kind: 'unknown';
};
/** One collected request header: the model-visible prompt and tool catalog. */
export interface TraceRequestHeader {
    /** The rendered system prompt text, when the request had one. */
    readonly system?: string;
    /** The assembled tool schemas (the request-time tool catalog). */
    readonly tools: readonly TraceToolSchema[];
    /** The provider/model route the request used. */
    readonly provider?: string;
    readonly model?: string;
    readonly contextWindow?: number;
}
/** Owned copy of one tool schema entry (name + description). */
export interface TraceToolSchema {
    readonly name: string;
    readonly description?: string;
}
/** The complete collected trace of one case run. */
export interface CaseTrace {
    /** The agent/session id the run executed in. */
    readonly sessionId: string;
    /** The first event sequence number included (the anchor). */
    readonly firstSeq: number;
    /** The last event sequence number included. */
    readonly lastSeq: number;
    /** Tool calls in log order. */
    readonly toolCalls: readonly ToolCallRecord[];
    /** The last non-empty assistant text, or '' when the run produced none. */
    readonly finalOutput: string;
    /** Summed token usage; absent when the adapter reported none. */
    readonly tokenUsage?: TraceTokenUsage;
    /** The final turn-end reason of the traced interval. */
    readonly turnEnd?: TraceTurnEnd;
    /** The last request header of the traced interval. */
    readonly requestHeader?: TraceRequestHeader;
}
/**
 * Fold the session events at or after `firstSeq` into a {@link CaseTrace}.
 * Events before the anchor (startup/seed) are excluded; the anchor is what
 * makes one case's trace independent of the agent's creation noise.
 * @param sessionId - the session the events belong to.
 * @param events - the session's event log in order.
 * @param firstSeq - the anchor sequence (inclusive).
 * @returns the owned trace.
 */
export declare function collectTrace(sessionId: SessionId, events: readonly SessionEvent[], firstSeq: number): CaseTrace;
/** Render one tool call as a compact single line (reports, review prompts). */
export declare function renderToolCall(call: ToolCallRecord): string;
//# sourceMappingURL=trace.d.ts.map