/**
 * `dsh-auto-review`, browser half: registers the locale dictionaries, the
 * scoped stylesheet, and the session-header review panel action. All data
 * arrives through the `autoReview` session projection; the approve buttons
 * execute the `/auto-review approve [n]` command through the commands
 * Remote namespace.
 *
 * @module dsh-auto-review/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type ReviewPanelLocaleKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Review panel copy. */
        'autoReviewPanel': ReviewPanelLocaleKey;
    }
}
export type { ReviewPanelProps, ReviewPanelInjected } from './ReviewPanel.js';
export type { ReviewPanelLocaleKey } from './locales.js';
export { presentVerdict, type PresentedVerdict, type VerdictTone } from './present.js';
/** Plugin name: matches the package name, the graph row id, and the bundle id. */
export declare const name = "dsh-auto-review";
/** Services the panel reads; `remote.commands` is mounted by the api-remotes client. */
export declare const inject: string[];
/**
 * Browser plugin body: dictionaries, the scoped stylesheet, and the
 * session-header action registration.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map